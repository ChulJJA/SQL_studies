As the attached .sql file, I have created necessary tables and random data manually.
Since I had no idea how to put random names in SQL, I just manually inserted 100 students with distinct names.
Also, when I try each queries in jdbc, I added sample data in SQL to check if my query is available or not.
